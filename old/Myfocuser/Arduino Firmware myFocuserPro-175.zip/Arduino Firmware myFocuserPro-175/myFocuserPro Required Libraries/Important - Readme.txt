Unzip the Arduino Firmware myFocuserPro v1xx.zip file
Locate the folder myFocuserPro Required Libraries, and in that folder 

There should be ELEVEN folders
	Bounce2
	myAFMotor
	myDallasTemperature
	myEEPROM
	myHalfStepper
	myIRRemote
	myOLED
	myQueue
	myRotaryEncoder
	newliquidCrystal
	OneWire

Move these folders to the Arduino\libraries folder in your Documents folder (for windows). Replace any existing folders or files.

Do not edit or replace any of these files. They have been edited and modified to use with the myFocuserPro firmware.
