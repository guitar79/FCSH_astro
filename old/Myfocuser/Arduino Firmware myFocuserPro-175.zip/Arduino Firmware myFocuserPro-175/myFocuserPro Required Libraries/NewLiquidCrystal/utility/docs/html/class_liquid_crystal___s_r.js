var class_liquid_crystal___s_r =
[
    [ "LiquidCrystal_SR", "class_liquid_crystal___s_r.html#ac3fe0b48f8d4c1c941d82d1333495cfc", null ],
    [ "send", "class_liquid_crystal___s_r.html#a03821351a32db07cb7e42c8c11ce8d47", null ],
    [ "setBacklight", "class_liquid_crystal___s_r.html#ad9f3e3f36257984c23fb508973e14535", null ],
    [ "setBacklightPin", "class_liquid_crystal___s_r.html#a5bfc0dcc1f042bcb59992493a3a7231d", null ]
];