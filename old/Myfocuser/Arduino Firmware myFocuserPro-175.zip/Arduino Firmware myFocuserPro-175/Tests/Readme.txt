This folder contains example tests for each option and driver board supported by myFocuserPro

This is for firmware 172 and higher

